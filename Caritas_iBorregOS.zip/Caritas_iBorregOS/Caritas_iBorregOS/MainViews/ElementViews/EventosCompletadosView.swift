//
//  EventosCompletadosView.swift
//  Caritas_iBorregOS
//
//  Created by Leo A.Molina on 14/10/24.
//

import SwiftUI

struct EventosCompletadosView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    EventosCompletadosView()
}
