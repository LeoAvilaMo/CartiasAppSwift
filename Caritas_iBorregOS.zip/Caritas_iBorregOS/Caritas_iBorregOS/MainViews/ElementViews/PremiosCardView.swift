//
//  PremiosCardView.swift
//  Caritas_iBorregOS
//
//  Created by Alumno on 03/10/24.
//

import SwiftUI

struct PremiosCardView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    PremiosCardView()
}
