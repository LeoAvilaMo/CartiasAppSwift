//
//  Usuario.swift
//  Caritas_iBorregOS
//
//  Created by Leo A.Molina on 30/08/24.
//

import Foundation

struct Usuarios {
    let ID_USUARIO: Int
    let NOMBRE: String
    let A_PATERNO: String
    let A_MATERNO: String
    let ID_TIPO_USUARIO: Int
}
