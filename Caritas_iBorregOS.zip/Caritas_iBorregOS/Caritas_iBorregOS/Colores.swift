//
//  Colores.swift
//  Caritas_iBorregOS
//
//  Created by Leo A.Molina on 27/08/24.
//

import Foundation
struct Colores {
    let blueC = Color(red: 0/255, green: 156/255, blue: 166/255)
    let darkBlueC = Color(red: 0/255, green: 59/255, blue: 92/255)
    let lightGreenC = Color(red: 209/255, green: 224/255, blue: 215/255)
    let whiteC = Color(red: 255/255, green: 255/255, blue: 255/255)
    let orangeC = Color(red: 255/255, green: 127/255, blue: 50/255)
    let pinkC = Color(red: 161/255, green: 90/255, blue: 149/255)
}
