//
//  Caritas_iBorregOSApp.swift
//  Caritas_iBorregOS
//
//  Created by Diego Torre on 27/08/24.
//

import SwiftUI

@main
struct Caritas_iBorregOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
